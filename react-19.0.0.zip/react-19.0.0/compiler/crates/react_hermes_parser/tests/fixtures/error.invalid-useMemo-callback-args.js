function component(a, b) {
  let x = useMemo((c) => a, []);
  return x;
}
