function foo() {
  let x = 0;
  for (let i = 0; i < 10; i = i + 1) {
    x = x + i;
  }
  return x;
}
