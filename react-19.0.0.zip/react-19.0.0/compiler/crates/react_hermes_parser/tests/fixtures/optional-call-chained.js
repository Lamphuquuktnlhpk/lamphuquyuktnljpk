function Component(props) {
  return call?.(props.a)?.(props.b)?.(props.c);
}
