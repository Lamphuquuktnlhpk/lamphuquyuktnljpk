function Component(props) {
  const x = { ["foo"]: props.foo };
  return x;
}
