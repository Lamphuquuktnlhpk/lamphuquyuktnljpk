# react_hermes_parser

Wrapper around the Hermes parser that exposes parse results as a `react_estree` AST.