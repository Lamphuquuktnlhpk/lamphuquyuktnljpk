function Component(props) {
  const x = {};
  const y = String(x);
  return [x, y];
}
