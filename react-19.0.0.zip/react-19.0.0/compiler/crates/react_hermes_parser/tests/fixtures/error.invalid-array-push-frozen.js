function Component(props) {
  const x = [];
  <div>{x}</div>;
  x.push(props.value);
  return x;
}
