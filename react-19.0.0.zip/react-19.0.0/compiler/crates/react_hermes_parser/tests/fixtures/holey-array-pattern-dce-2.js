function t(props) {
  let [foo, bar, ,] = props;
  return foo;
}
