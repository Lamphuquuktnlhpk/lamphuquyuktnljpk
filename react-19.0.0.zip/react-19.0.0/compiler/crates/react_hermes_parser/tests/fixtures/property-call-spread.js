function Component(props) {
  const x = foo.bar(...props.a, null, ...props.b);
  return x;
}
