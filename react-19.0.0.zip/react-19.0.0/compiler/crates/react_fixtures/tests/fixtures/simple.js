function test() {
  [true, false, null, 1, 3.14, ...["hello world!"]];
  return 2;
}
